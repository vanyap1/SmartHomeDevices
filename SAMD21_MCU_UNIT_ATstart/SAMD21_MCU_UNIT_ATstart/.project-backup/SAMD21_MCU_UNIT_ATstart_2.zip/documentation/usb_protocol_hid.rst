================
USB HID Protocol
================

USB HID Protocol is a part of the USB Device Stack library. It provides basic
macro definitions and data structures which are compliant with HID(Human Interface
Device) Specification version 1.11.


Applications
------------

N/A

Dependencies
------------

N/A


Limitations
-----------

N/A
