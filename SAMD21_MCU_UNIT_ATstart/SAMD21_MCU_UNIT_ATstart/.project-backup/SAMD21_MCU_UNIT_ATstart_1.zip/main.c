#include <atmel_start.h>






static uint8_t hid_generic_in_report[64];
static uint8_t hid_generic_out_report[64];
uint8_t packNum = 0;

static bool usb_device_cb_generic_out(const uint8_t ep, const enum usb_xfer_code rc, const uint32_t count)
{
	hiddf_generic_read(hid_generic_out_report, sizeof(hid_generic_out_report));
	
	if (hid_generic_out_report[0] == 0) {
		// led be off
		switch (hid_generic_out_report[1]) {
			case 1:
			//gpio_set_pin_level(DB_LED, true);
			break;
			case 2:
			//gpio_set_pin_level(DB_LED, false);
			break;
		}
	}
	hid_generic_in_report[0] = packNum;
	hid_generic_in_report[5] = 0x55;
	hid_generic_in_report[6] = true ? 0x00 : 0xff;
	hiddf_generic_write(hid_generic_in_report, sizeof(hid_generic_in_report));
	if(packNum == 255) packNum=0;
	packNum++;
	return false;
}






int main(void)
{
	atmel_start_init();
	hid_generic_example();
	hiddf_generic_register_callback(HIDDF_GENERIC_CB_READ, (FUNC_PTR)usb_device_cb_generic_out);
	hiddf_generic_read(hid_generic_out_report, sizeof(hid_generic_out_report));
	
	while (1) {
		gpio_toggle_pin_level(DB_LED);
		delay_ms(500);
	}
}
